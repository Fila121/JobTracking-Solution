USE JobTracking_data;
GO

PRINT 'Adding sample data to JobTracking_data...';

-- Check if tables exist
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Clients')
BEGIN
    PRINT 'Clients table missing. Run app (F5) first to create schema via EF migrations.';
    RETURN;
END

-- Clear sample data only (don't delete user data)
DELETE FROM Clients WHERE CompanyName IN ('Ubuntu Creations', 'Northern Tech Solutions');
DELETE FROM Employees WHERE FirstName IN ('Alice', 'Bob', 'Carol');

-- Insert sample clients
INSERT INTO Clients (CompanyName, ContactName) VALUES 
('Ubuntu Creations', 'Themba Khumalo'),
(' Northern Tech Solutions', 'Samantha Smith'),
('Global Contract', 'Casper Johnson');

PRINT 'Clients inserted';

-- Insert sample employees
INSERT INTO Employees (FirstName, LastName, Email) VALUES 
('Alice', 'Johnson', 'ajohnson@email.com'),
('Bob', 'Williams', 'williamsb@email.com'),
('Carol', 'Davis', 'carold@company.com');

PRINT 'Employees inserted';

-- Verify
SELECT 'Clients' AS TableName, COUNT(*) AS RecordCount FROM Clients
UNION ALL
SELECT 'Employees', COUNT(*) FROM Employees;

PRINT 'Sample data ready! Test /Jobs/Create in app.';