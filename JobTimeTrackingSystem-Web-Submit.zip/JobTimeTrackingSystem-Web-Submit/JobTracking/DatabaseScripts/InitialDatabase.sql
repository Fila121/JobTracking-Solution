IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
CREATE TABLE [Clients] (
    [ClientId] int NOT NULL IDENTITY,
    [CompanyName] nvarchar(max) NOT NULL,
    [Phone] nvarchar(max) NOT NULL,
    [ContactName] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_Clients] PRIMARY KEY ([ClientId])
);

CREATE TABLE [Employees] (
    [EmployeeId] int NOT NULL IDENTITY,
    [FirstName] nvarchar(max) NOT NULL,
    [LastName] nvarchar(max) NOT NULL,
    [Email] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_Employees] PRIMARY KEY ([EmployeeId])
);

CREATE TABLE [Jobs] (
    [JobNo] nvarchar(450) NOT NULL,
    [JobType] nvarchar(20) NOT NULL,
    [JobDate] datetime2 NOT NULL,
    [ClientId] int NOT NULL,
    CONSTRAINT [PK_Jobs] PRIMARY KEY ([JobNo]),
    CONSTRAINT [FK_Jobs_Clients_ClientId] FOREIGN KEY ([ClientId]) REFERENCES [Clients] ([ClientId]) ON DELETE CASCADE
);

CREATE TABLE [TimeCards] (
    [TimeCardId] int NOT NULL IDENTITY,
    [EmployeeId] int NOT NULL,
    [JobNo] nvarchar(450) NOT NULL,
    [DateWorked] datetime2 NOT NULL,
    [Hours] decimal(18,2) NOT NULL,
    [Notes] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_TimeCards] PRIMARY KEY ([TimeCardId]),
    CONSTRAINT [FK_TimeCards_Employees_EmployeeId] FOREIGN KEY ([EmployeeId]) REFERENCES [Employees] ([EmployeeId]) ON DELETE CASCADE,
    CONSTRAINT [FK_TimeCards_Jobs_JobNo] FOREIGN KEY ([JobNo]) REFERENCES [Jobs] ([JobNo]) ON DELETE CASCADE
);

CREATE INDEX [IX_Jobs_ClientId] ON [Jobs] ([ClientId]);

CREATE INDEX [IX_TimeCards_EmployeeId] ON [TimeCards] ([EmployeeId]);

CREATE INDEX [IX_TimeCards_JobNo] ON [TimeCards] ([JobNo]);

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20251016131816_intitial create', N'9.0.10');

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20251017063245_AllowNotesNull', N'9.0.10');

COMMIT;
GO