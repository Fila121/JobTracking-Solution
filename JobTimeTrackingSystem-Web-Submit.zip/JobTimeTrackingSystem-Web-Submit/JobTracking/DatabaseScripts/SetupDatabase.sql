--Setup for JobTracking_data
PRINT 'Setting up JobTracking_data database';

USE master;
GO

-- Create database if missing
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'JobTracking_data')
BEGIN
    CREATE DATABASE JobTracking_data;
    PRINT 'Database JobTracking_data created';
END
ELSE
BEGIN
    PRINT 'Database JobTracking_data already exists';
END
GO

USE JobTracking_data;
GO

PRINT 'Database ready. EF Core will create tables on first app run.';
PRINT 'Run SeedData.sql after tables exist for sample data.';