DATABASE SCRIPTS USAGE


1. SETUP DATABASE (Recommended)
   - Open SQL Server Management Studio (SSMS)
   - Connect to: (localdb)\MSSQLLocalDB
   - Run: SetupDatabase.sql
   - Creates DB + sample data automatically

2. MANUAL SETUP
   - Run: InitialDatabase.sql (schema from EF migrations)
   - Run: SeedData.sql (sample clients/employees)

3. VERIFY
   - Run: VerifySetup.sql
   - Should show for Clients and Employees

4. CONNECTION STRING (appsettings.json)
   Server=(localdb)\MSSQLLocalDB;Database=JobTrackingDB;Trusted_Connection=True;TrustServerCertificate=True;
