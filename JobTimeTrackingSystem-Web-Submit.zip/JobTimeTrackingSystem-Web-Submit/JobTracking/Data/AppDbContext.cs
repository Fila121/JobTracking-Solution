﻿using JobTracking.Models;
using Microsoft.EntityFrameworkCore;

namespace JobTracking.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Job> Jobs { get; set; }
        public DbSet<TimeCard> TimeCards { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure JobNo as primary key
            modelBuilder.Entity<Job>()
                .HasKey(j => j.JobNo);

            // Configure JobType constraint
            modelBuilder.Entity<Job>()
                .Property(j => j.JobType)
                .HasConversion<string>()
                .IsRequired()
                .HasMaxLength(20);

            // Configure relationships
            modelBuilder.Entity<Job>()
                .HasOne(j => j.Client)
                .WithMany(c => c.Jobs)
                .HasForeignKey(j => j.ClientId);

            modelBuilder.Entity<TimeCard>()
                .HasOne(tc => tc.Employee)
                .WithMany(e => e.TimeCards)
                .HasForeignKey(tc => tc.EmployeeId);

            modelBuilder.Entity<TimeCard>()
                .HasOne(tc => tc.Job)
                .WithMany(j => j.TimeCards)
                .HasForeignKey(tc => tc.JobNo);

        }
    }
}
