﻿using JobTracking.Models;

namespace JobTracking.Data.Repositories
{
    public interface IRepository
    {
        Task<List<Job>> GetAllJobsAsync();
        Task<Job?> GetJobByNoAsync(string jobNo);
        Task<bool> JobExistsAsync(string jobNo);
        Task AddJobAsync(Job job);
        Task UpdateJobAsync(Job job);
        Task AddTimeCardAsync(TimeCard timeCard);
        Task<List<TimeCard>> GetTimeCardsByJobAsync(string jobNo);
        Task<List<Client>> GetAllClientsAsync();
        Task<List<Employee>> GetAllEmployeesAsync();
        Task<int> SaveChangesAsync();
    }
}
