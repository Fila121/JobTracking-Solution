﻿using Microsoft.EntityFrameworkCore;
using JobTracking.Data;
using JobTracking.Models;

namespace JobTracking.Data.Repositories
{
    public class Repository : IRepository
    {
        private readonly AppDbContext _context;

        public Repository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Job>> GetAllJobsAsync()
        {
            return await _context.Jobs
                .Include(j => j.Client)
                .OrderByDescending(j => j.JobDate)
                .ToListAsync();
        }

        public async Task<Job?> GetJobByNoAsync(string jobNo)
        {
            return await _context.Jobs
                .Include(j => j.Client)
                .FirstOrDefaultAsync(j => j.JobNo == jobNo);
        }

        public async Task<bool> JobExistsAsync(string jobNo)
        {
            return await _context.Jobs.AnyAsync(j => j.JobNo == jobNo);
        }

        public async Task AddJobAsync(Job job)
        {
            await _context.Jobs.AddAsync(job);
        }

        public async Task UpdateJobAsync(Job job)
        {
            _context.Jobs.Update(job);
        }

        public async Task AddTimeCardAsync(TimeCard timeCard)
        {
            await _context.TimeCards.AddAsync(timeCard);
        }

        public async Task<List<TimeCard>> GetTimeCardsByJobAsync(string jobNo)
        {
            return await _context.TimeCards
                .Include(tc => tc.Employee)
                .Where(tc => tc.JobNo == jobNo)
                .OrderBy(tc => tc.DateWorked)
                .ToListAsync();
        }

        public async Task<List<Client>> GetAllClientsAsync()
        {
            return await _context.Clients
                .OrderBy(c => c.CompanyName)
                .ToListAsync();
        }

        public async Task<List<Employee>> GetAllEmployeesAsync()
        {
            return await _context.Employees
                .OrderBy(e => e.FirstName)
                .ThenBy(e => e.LastName)
                .ToListAsync();
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
