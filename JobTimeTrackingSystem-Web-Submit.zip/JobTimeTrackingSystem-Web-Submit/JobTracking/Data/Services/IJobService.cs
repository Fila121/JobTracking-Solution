﻿using JobTracking.Models;

namespace JobTracking.Data.Services
{
    public interface IJobService
    {
        Task<string> GenerateJobNumberAsync(string jobType);
        Task<Job> CreateJobAsync(Job job);
        Task UpdateJobAsync(Job job);
        Task<TimeCard> CreateTimeCardAsync(TimeCard timeCard);
    }
}
