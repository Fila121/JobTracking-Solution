﻿using Microsoft.EntityFrameworkCore;
using JobTracking.Data;
using JobTracking.Models;
using JobTracking.Data.Repositories;

namespace JobTracking.Data.Services
{
    public class JobService : IJobService
    {
        private readonly AppDbContext _context;
        private readonly IRepository _repository;

        public JobService(AppDbContext context, IRepository repository)
        {
            _context = context;
            _repository = repository;
        }

        public async Task<string> GenerateJobNumberAsync(string jobType)
        {
            string prefix = jobType switch
            {
                "Repair" => "R",
                "Support" => "S",
                "Warranty" => "W",
                _ => throw new ArgumentException("Invalid job type")
            };

            var lastJob = await _context.Jobs
                .Where(j => j.JobNo.StartsWith(prefix))
                .OrderByDescending(j => j.JobNo)
                .FirstOrDefaultAsync();

            int nextNumber = 1;
            if (lastJob != null && lastJob.JobNo.Length == 6)
            {
                if (int.TryParse(lastJob.JobNo[1..], out int currentNumber))
                {
                    nextNumber = currentNumber + 1;
                }
            }

            return $"{prefix}{nextNumber:D5}"; // R00001, S00001, etc.
        }

        public async Task<Job> CreateJobAsync(Job job)
        {
            job.JobNo = await GenerateJobNumberAsync(job.JobType);
            await _repository.AddJobAsync(job);
            await _repository.SaveChangesAsync();
            return job;
        }

        public async Task UpdateJobAsync(Job job)
        {
            await _repository.UpdateJobAsync(job);
            await _repository.SaveChangesAsync();
        }

        public async Task<TimeCard> CreateTimeCardAsync(TimeCard timeCard)
        {
            await _repository.AddTimeCardAsync(timeCard);
            await _repository.SaveChangesAsync();
            return timeCard;
        }
    }
}