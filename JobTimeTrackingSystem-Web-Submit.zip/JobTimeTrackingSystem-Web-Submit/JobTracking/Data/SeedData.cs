﻿using JobTracking.Models;

namespace JobTracking.Data
{
    public static class SeedData
    {
        public static async Task EnsurePopulatedAsync(AppDbContext context)
        {
            // Seed employees if none exist
            if (!context.Employees.Any())
            {
                var employees = new[]
                {
                    new Employee { FirstName = "Alice Johnson" },
                    new Employee { FirstName = "Bob Williams" },
                    new Employee { FirstName = "Carol Davis" }
                };
                context.Employees.AddRange(employees);
                await context.SaveChangesAsync();
            }
        }
    }
}
