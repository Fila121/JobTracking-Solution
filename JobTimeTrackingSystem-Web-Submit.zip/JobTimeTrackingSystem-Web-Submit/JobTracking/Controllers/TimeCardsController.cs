﻿using JobTracking.Data.Repositories;
using JobTracking.Data.Services;
using JobTracking.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace JobTracking.Controllers
{
    public class TimeCardsController : Controller
    {
        private readonly IRepository _repository;
        private readonly IJobService _jobService;

        public TimeCardsController(IRepository repository, IJobService jobService)
        {
            _repository = repository;
            _jobService = jobService;
        }

        public async Task<IActionResult> Create(string jobNo)
        {
            Console.WriteLine($"TimeCards.Create called with jobNo: '{jobNo}'");
            if (string.IsNullOrEmpty(jobNo)) 
                return RedirectToAction("Index", "Jobs");

            var jobExists = await _repository.JobExistsAsync(jobNo);
            if (!jobExists)
            {
                TempData["Error"] = "Job not found.";
                return RedirectToAction("Index", "Jobs");
            }

            ViewBag.JobNo = jobNo;       
            var employees = await _repository.GetAllEmployeesAsync();
            var employeeSelectList = employees.Select(e => new SelectListItem
            {
                Value = e.EmployeeId.ToString(),
                Text = e.FullName, 
                Selected = false
            }).ToList();

            ViewBag.Employees = employeeSelectList;
            return View(new TimeCardViewModel { JobNo = jobNo, DateWorked = DateTime.Today });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TimeCardViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var timeCard = new TimeCard
                    {
                        EmployeeId = model.EmployeeId,
                        JobNo = model.JobNo,
                        DateWorked = model.DateWorked,
                        Hours = model.HoursWorked,
                        Notes = model.Notes
                    };

                    await _jobService.CreateTimeCardAsync(timeCard);
                    TempData["Success"] = "Time card recorded successfully!";
                    return RedirectToAction("TimeCards", "Jobs", new { jobNo = model.JobNo });
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Controller error: {ex.Message}");
                    Console.WriteLine($"Inner exception: {ex.InnerException?.Message}");
                    ModelState.AddModelError("", $"Error: {ex.InnerException?.Message ?? ex.Message}");
                }
            }

            ViewBag.JobNo = model.JobNo;
            ViewBag.JobNo = model.JobNo;
            var employees = await _repository.GetAllEmployeesAsync();
            var employeeSelectList = employees.Select(e => new SelectListItem
            {
                Value = e.EmployeeId.ToString(),
                Text = e.FullName
            }).ToList();

            ViewBag.Employees = employeeSelectList;
            return View(model);
        }
    }
}

