﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using JobTracking.Data.Repositories;
using JobTracking.Data.Services;
using JobTracking.Models;
using System.ComponentModel.DataAnnotations;

namespace JobTracking.Controllers
{
    public class JobsController : Controller
    {
        private readonly IRepository _repository;
        private readonly IJobService _jobService;

        public JobsController(IRepository repository, IJobService jobService)
        {
            _repository = repository;
            _jobService = jobService;
        }

        public async Task<IActionResult> Index()
        {
            var jobs = await _repository.GetAllJobsAsync();
            var model = jobs.Select(j => new JobViewModel
            {
                JobNo = j.JobNo,
                JobType = j.JobType,
                JobDate = j.JobDate,
                ClientId = j.ClientId,
                ClientName = j.Client.CompanyName
            }).ToList();
            return View(model);
        }

        public async Task<IActionResult> Create()
        {
            ViewBag.Clients = new SelectList(await _repository.GetAllClientsAsync(), "ClientId", "CompanyName");
            ViewBag.JobTypes = new SelectList(new[] { "Repair", "Support", "Warranty" });
            return View(new JobViewModel { JobDate = DateTime.Today });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(JobViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var job = new Job
                    {
                        JobType = model.JobType,
                        JobDate = model.JobDate,
                        ClientId = model.ClientId
                    };

                    await _jobService.CreateJobAsync(job);  //Generate JobNo with dynamic prefix
                    TempData["Success"] = $"Job {job.JobNo} created successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error creating job: {ex.Message}");
                }
            }

            ViewBag.Clients = new SelectList(await _repository.GetAllClientsAsync(), "ClientId", "CompanyName");
            ViewBag.JobTypes = new SelectList(new[] { "Repair", "Support", "Warranty" });
            return View(model);
        }

        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var job = await _repository.GetJobByNoAsync(id);
            if (job == null) return NotFound();

            var model = new JobViewModel
            {
                JobNo = job.JobNo,
                JobType = job.JobType,
                JobDate = job.JobDate,
                ClientId = job.ClientId,
                ClientName = job.Client.CompanyName
            };

            ViewBag.Clients = new SelectList(await _repository.GetAllClientsAsync(), "ClientId", "CompanyName");
            ViewBag.JobTypes = new SelectList(new[] { "Repair", "Support", "Warranty" });
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, JobViewModel model)
        {
            if (id != model.JobNo) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    var job = await _repository.GetJobByNoAsync(model.JobNo);
                    if (job == null) return NotFound();

                    job.JobType = model.JobType;
                    job.JobDate = model.JobDate;
                    job.ClientId = model.ClientId;

                    await _jobService.UpdateJobAsync(job);
                    TempData["Success"] = $"Job {job.JobNo} updated successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error updating job: {ex.Message}");
                }
            }

            ViewBag.Clients = new SelectList(await _repository.GetAllClientsAsync(), "ClientId", "CompanyName");
            ViewBag.JobTypes = new SelectList(new[] { "Repair", "Support", "Warranty" });
            return View(model);
        }

        public async Task<IActionResult> TimeCards(string jobNo)
        {
            if (string.IsNullOrEmpty(jobNo)) return RedirectToAction(nameof(Index));

            var jobExists = await _repository.JobExistsAsync(jobNo);
            if (!jobExists) return NotFound();

            var timeCards = await _repository.GetTimeCardsByJobAsync(jobNo);
            var model = timeCards.Select(tc => new TimeCardViewModel
            {
                TimeCardId = tc.TimeCardId,
                EmployeeId = tc.EmployeeId,
                JobNo = tc.JobNo,
                DateWorked = tc.DateWorked,
                HoursWorked = tc.Hours,
                Notes = tc.Notes,
                EmployeeName = $"{tc.Employee?.FirstName} {tc.Employee?.LastName}".Trim()
            }).ToList();

            ViewBag.JobNo = jobNo;
            ViewBag.JobType = (await _repository.GetJobByNoAsync(jobNo))?.JobType ?? "";
            return View(model);
        }
    }

   
}