﻿using System.ComponentModel.DataAnnotations;

namespace JobTracking.Models
{
    public class JobViewModel
    {
        public string JobNo { get; set; } = string.Empty;

        [Required]
        public string JobType { get; set; } = string.Empty;

        [Required]
        public DateTime JobDate { get; set; } = DateTime.Today;

        [Required]
        public int ClientId { get; set; }

        public string ClientName { get; set; } = string.Empty;
    }
}
