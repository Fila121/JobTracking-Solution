﻿namespace JobTracking.Models
{
    public class Job
    {
        public string JobNo { get; set; } 
        public string JobType { get; set; } 
        public DateTime JobDate { get; set; }
        public int ClientId { get; set; }
        public Client Client { get; set; }
        public ICollection<TimeCard> TimeCards { get; set; }
    }
}
