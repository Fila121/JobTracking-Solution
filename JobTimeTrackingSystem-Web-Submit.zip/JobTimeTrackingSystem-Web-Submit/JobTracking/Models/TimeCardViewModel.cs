﻿using System.ComponentModel.DataAnnotations;

namespace JobTracking.Models
{
    public class TimeCardViewModel
    {
        public int TimeCardId { get; set; }

        [Required]
        public int EmployeeId { get; set; }

        public string JobNo { get; set; } = string.Empty;

        [Required]
        public DateTime DateWorked { get; set; } = DateTime.Today;

        [Required]
        [Range(0.1, 24)]
        public decimal HoursWorked { get; set; }

        public string? Notes { get; set; }

        public string EmployeeName { get; set; } = string.Empty;
    }
}
