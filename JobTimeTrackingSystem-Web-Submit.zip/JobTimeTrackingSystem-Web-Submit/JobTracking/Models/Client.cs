﻿namespace JobTracking.Models
{
    public class Client
    {
        public int ClientId { get; set; }
        public string CompanyName { get; set; }
        public string Phone { get; set; }
        public string ContactName { get; set; }
        public ICollection<Job> Jobs { get; set; }
    }
}
