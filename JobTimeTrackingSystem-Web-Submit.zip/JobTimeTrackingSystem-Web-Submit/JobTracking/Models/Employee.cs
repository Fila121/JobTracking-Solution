﻿namespace JobTracking.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }

        public string FullName => $"{FirstName} {LastName}".Trim();
        public ICollection<TimeCard> TimeCards { get; set; }
    }
}
