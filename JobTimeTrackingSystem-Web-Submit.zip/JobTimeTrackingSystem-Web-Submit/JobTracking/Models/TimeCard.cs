﻿namespace JobTracking.Models
{
    public class TimeCard
    {
        public int TimeCardId { get; set; }
        public int EmployeeId { get; set; }
        public Employee Employee { get; set; } = null!;
        public string JobNo { get; set; }
        public Job Job { get; set; } = null!;
        public DateTime DateWorked { get; set; }
        public decimal Hours { get; set; }
        public string Notes { get; set; }
    }


}
