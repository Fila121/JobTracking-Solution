using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace JobTracking.Views.Jobs
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
