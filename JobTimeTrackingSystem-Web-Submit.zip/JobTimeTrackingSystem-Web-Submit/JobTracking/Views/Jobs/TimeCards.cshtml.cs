using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace JobTracking.Views.Jobs
{
    public class TimeCardsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
