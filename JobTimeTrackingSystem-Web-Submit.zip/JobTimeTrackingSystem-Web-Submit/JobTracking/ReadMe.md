﻿# Job Tracking Web Application

A full-featured **ASP.NET Core MVC** web application for managing jobs, clients, employees, and time tracking. Built with **Entity Framework Core**, **Repository Pattern**, and **responsive Bootstrap UI**.

## Features

- **Dynamic Job Numbering**: Auto-generates `JobNo` from first letter of `JobType` + sequence (e.g., "R00001" for "Repair")
- **Time Tracking**: Record employee hours per job with optional notes and date selection
- **Client & Employee Management**: CRUD operations with full-name dropdowns for employees
- **Repository Pattern**: Clean data access layer with `IRepository` interface
- **Entity Framework Core**: Code-first migrations with SQL Server LocalDB
- **Responsive UI**: Bootstrap 5 with mobile-friendly design
- **Model Validation**: Client-side and server-side validation with data annotations
- **Error Handling**: User-friendly error messages and try-catch blocks

## Technology Stack

- **Backend**: ASP.NET Core 8.0 MVC
- **Database**: Entity Framework Core 8.0 + SQL Server LocalDB
- **ORM**: Code-first migrations with `AppDbContext`
- **Architecture**: Repository pattern + Service layer (`IJobService`)
- **Frontend**: Bootstrap 5, Razor views, jQuery validation
- **Validation**: Data annotations + ModelState checks

## Project Structure
JobTracking/
├── Controllers/           # MVC Controllers (Jobs, TimeCards, Clients, Employees)
├── Data/                 # DbContext, Repositories, Services
│   ├── AppDbContext.cs
│   ├── Repositories/
│   └── Services/
├── Models/               # Entity models + ViewModels
├── Views/                # Razor views
├── wwwroot/              # Static files (CSS, JS, images)
├── DatabaseScripts/      # SQL setup scripts
├── JobTracking.sln
└── appsettings.json      # Connection: JobTracking_data


## Quick Start

### Prerequisites
- **Visual Studio 2022** (ASP.NET and web development workload)
- **SQL Server LocalDB** (included with Visual Studio)
- **.NET 8.0 SDK**

### Step 1: Open and Build
1. Open `JobTracking.sln` in Visual Studio 2022
2. **Right-click Solution** → **Restore NuGet Packages**
3. **Build** → **Build Solution** (Ctrl+Shift+B)

### Step 2: Database Setup
**Automatic (Recommended)**:
1. **Press F5** → EF Core automatically:
   - Creates `JobTracking_data` database
   - Applies migrations (creates tables: Clients, Employees, Jobs, TimeCards)
   - Schema ready for use

**Manual Sample Data**:
1. Open **SQL Server Management Studio (SSMS)**
2. Connect to `(localdb)\MSSQLLocalDB`
3. Run `USE JobTracking_data; GO`
4. Execute `DatabaseScripts/SeedData.sql` → Adds sample clients/employees


### Step 3: Run Application
1. **F5** or **Ctrl+F5** to start
2. Navigate to `/Jobs` → View jobs list
3. **Create New Job**:
   - Select client from dropdown
   - Enter job type (e.g., "Repair") → Auto-generates "R00001"
   - Save → Dynamic JobNo created
4. **Record Time Card**:
   - Click job → "Record Time Card"
   - Select employee
   - Enter hours and date
   - Notes field

## Database: JobTracking_data

**Connection String** (appsettings.json):
```json
"DefaultConnection": "Server=(localdb)\\MSSQLLocalDB;Database=JobTracking_data;Trusted_Connection=True;TrustServerCertificate=True;"

